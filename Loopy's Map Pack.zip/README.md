_*This map pack is made to hopefully not be too laggy and to be good quality.*_



### _*WARNING: Map animations may not work when using the mod called map embiggerner and increasing or descreasing map size*_



# _*Currently this adds 28 Unique maps to  the game called.*_


* Calm bridge


* Elemental Towers


* Mechanical Mayhem


* Sawprise Attack


* Elemental Arena


* Rainbow Road



* Aquatic Attack



* Aqua Oasis



* Dodgy Ladder



* Heated Arena



* Lunar Orbit



* Frog fight



* Crystal Caverns



* Skeletal Star



* Climbing Castle



* Stepping Stones



* Circular Pyramid



* Basic Battle



* Magmatic Laboratory



* Magma Towers




* Floating Battlefield



* Solar Star



* Blazing Honeycombs



* Uneven Waves




* Party Platforms



* Acid Arena



* Sunset Valley




## _*Important Changelogs:*_



2.2.0:

added 2 new maps:

Slithering Surprise


Volcanic Rays

2.1.9:
updated a few maps. hopefully fixed any broken ones.



2.1.8:
added 1 new map called Sunset Valley that as something to do with the sun and the moon.



2.1.7: 

added 2 new maps called Party Platforms and Acid Arena.


2.1.5: 

removed unbalanced pedestal since the main part of the map is broken.


2.1.4:

added a new map called Uneven Waves.


2.1.2:

added a new map called Blazing Honeycombs.



2.1.1:


updated calm bridge with ways to get up to the top and add some disappering platforms to the actual bridge.

updated rainbow road.

2.1.0:

updated some maps that had hard to reach areas with platforms so people who spawn at the top have less of a advantage.



2.0.8:

added a new map called Solar Star.




2.0.7:
Added a L symbol to all my maps so people can tell they are mine when in a game. updated the look of the maps Rainbow Road and Lunar Orbit.




2.0.5:
updated all my maps to be compatible with the new maps extended update.





2.0.0:
added 1 new map  called Floating Battlefield and updated some maps  with the new animation feature.




1.95:

added 2 new maps:


Magmatic Laboratory


Magma Towers



1.90:
removed a map and added a map called Heated arena.


1.80:
updated aqua oasis .




1.75:


released 4 maps.

Climbing Castle.

Stepping Stones.

Circular Pyramid.

Basic Battle.




1.70:


removed 2 maps as they were bad and didnt have the same quallity as others.


1.67:

updated some maps .




1.60:

Added 3 new maps

Frog fight


Crystal Caverns


Skeletal Star


1.50:

Added 3 new maps

Aqua Oasis

Dodgy Ladder

Lunar Orbit



1.40:
Updated a few maps and released 2 new maps.

Astral Battlefield.
Aquatic Attack.



1.03:

Updated Elemental Towers.
Added 3 new maps

Elemental Arena

Rainbow Road

Unbalanced Pedestal

